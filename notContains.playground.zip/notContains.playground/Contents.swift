import UIKit

let array: [Int] = [10, 205, 213, 43, 21, -5, -345, 0]

func notContains(array: [Int]) -> Int {
    
    let arr = array.filter { $0 > 0 }
    let max = arr.max()
    var result = 0
    
    for i in 1...max! {
        if (arr.contains(i) == false) {
            result = i
            break
        }
        
    }
    
    return result
}

print(notContains(array: array))
