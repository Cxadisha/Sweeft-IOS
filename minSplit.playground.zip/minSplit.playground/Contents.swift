import UIKit

func minSplit(amount: Int) -> Int {
    
    var count = 0
    var balance = amount
    
    while (balance != 0) {
        if (balance >= 50) {
            count += 1
            balance -= 50
        } else if (balance >= 20 && balance < 50) {
            count += 1
            balance -= 20
        } else if  (balance >= 10 && balance < 50) {
            count += 1
            balance -= 10
        } else if (balance >= 5 && balance < 10) {
            count += 1
            balance -= 5
        } else if (balance < 5) {
            count += 1
            balance -= 1
        }
    }
    
    return count
}

print(minSplit(amount: 134))

