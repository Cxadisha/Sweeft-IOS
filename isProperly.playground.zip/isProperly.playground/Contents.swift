import UIKit

let str = "()()(())"

func isProperly(text: String) -> Bool {
    
    var openedBrackets = 0
    var closedBrackets = 0
    var properlyOrdered = true
    
    text.forEach { i in
        
        if (i == "(") {
            openedBrackets += 1
        } else if (i == ")") {
            closedBrackets += 1
        }
        
        if (closedBrackets > openedBrackets) { properlyOrdered = false }
    }
    
    if (openedBrackets == closedBrackets && properlyOrdered == true) {
        return true
    }
    return false
}

print(isProperly(text: str))
