import UIKit

func countVariants(stearsCount: Int) -> Int {
    
    if (stearsCount == 0) {
        return 1
    } else if (stearsCount < 0) {
        return 0
    } else {
        return countVariants(stearsCount: stearsCount - 2) + countVariants(stearsCount: stearsCount - 1)
    }
}

print(countVariants(stearsCount: 6))
